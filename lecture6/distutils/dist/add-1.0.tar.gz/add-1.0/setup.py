from distutils.core import setup, Extension

setup(
    name='add',
    version='1.0',
    url='http://www.blah.com',
    author='Me',
    author_email='me@me.com',
    description='Add description',
    ext_modules=[],
    py_modules=['add']
)

